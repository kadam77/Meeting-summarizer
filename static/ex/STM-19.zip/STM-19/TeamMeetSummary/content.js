let transcript="";
// let meetId =""; 
let email_id = "";

//listerning email id dynamic
chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
    if (request.myVariable) {
      email_id = request.myVariable;
      alert(email_id);
      // do something with myValue
    }
  });

  
window.onload=func;
var a1 = document.createElement("a");

// code to click end meet button
// const end_button = document.querySelector("#yDmH0d > div.VfPpkd-Sx9Kwc.cC1eCc.UDxLd.PzCPDd.Qb2h6b.VfPpkd-Sx9Kwc-OWXEXe-FNFY6c.VfPpkd-Sx9Kwc-OWXEXe-s2gQvd > div.VfPpkd-wzTsW > div > div.VfPpkd-T0kwCb > button:nth-child(2) > span");
// if(end_button != null)
// {
//     end_button.addEventListener('click',summary());
// }
function summary(){
    // alert("something happens");

    // const data  = '"text:"'+'"'+transcript+'"'; //data to send over http request
    const data = transcript;
    // const obj = JSON.parse(data);
    //Uisg fetch api

    fetch('http://127.0.0.1:8000/predict',{
        method:'POST',
        headers:{
            'Content-Type':'application/json'
        },
        body: JSON.stringify({
            Transcript: transcript,
            MeetId: "meetId",
            Email_id: email_id

            
        })
    })
    .then(response => response.json())
    .then(data => {
        if(data["status"] == "send")
        {
            alert("Email send successfully, Please also check spam!");
        }
        else{
            alert("Error");
        }
    })
    .catch(error => {
        console.error(error);
    });
   

    //code to end the meet automatically if generate button is nedded
//         const end_button = document.querySelector("#yDmH0d > div.VfPpkd-Sx9Kwc.cC1eCc.UDxLd.PzCPDd.Qb2h6b.VfPpkd-Sx9Kwc-OWXEXe-FNFY6c.VfPpkd-Sx9Kwc-OWXEXe-s2gQvd > div.VfPpkd-wzTsW > div > div.VfPpkd-T0kwCb > button:nth-child(2) > span");
// if(end_button != null)
//  {
//      end_button.click();
//  }
}
//end of meet
window.addEventListener('beforeunload', function (e) {
    e.preventDefault();
    // e.returnValue = "summary will be send to ur email!";
    if(transcript.length>0){
        alert("Email send successfully, Please also check spam!");// writing alert here because the mail is send after the tab is closed in between the page is changed we cannot get alert from summary()
        var filedata = "Meeting-id: "+"meetId"+"\n"+"Host email-id: "+email_id+"\n"+transcript; 
        var blob1 = new Blob([filedata], {type: "text/plain;charset=utf-8"});
    // saveAs(blob1, "myScript.txt");

    //Alternative
    
    a1.href = window.URL.createObjectURL(blob1);
    a1.download = ("meetId"+"Script.txt");
    a1.click();
    

    // code to  send post request to ML model using api
    summary();
    

    }
// import { writeFile } from 'fs';
//e.returnValue = '';
});

function func()
{
    
    //verifying email id taken properly
    console.log(email_id);
    
    const button = document.createElement("button");
    button.id = "recordTranscript";
    button.textContent = "Start";
    button.style.backgroundColor="rgb(47, 255, 68)";
    button.style.position= "absolute";
    button.style.bottom = "27px";
    button.style.zIndex="112";
    button.style.right="260px";
    button.style.height="30px";
    button.style.width="80px"

    

    document.querySelector("body").prepend(button);//inserting a 'start' button.

    button.addEventListener('click',onCaption);//clicking to start

    //capturing meeting id
/*

    */
    

    
}

function onCaption(){

//taking users email.id
console.log(email_id);


//globally variable access
var i = document.querySelector('iframe');
var body =i.contentDocument.childNodes[1].childNodes[1];
//this is done so because all is covered in iframe hence direct access not allowed

    var a = body.querySelector("#callingButtons-showMoreBtn");
//    
    if(a!=null){
    a.click();

    var b = body.querySelector("#LanguageSpeechMenuControl-id");
    setTimeout(()=>{
    if(b!=null)
    {
        b.click();
        
        var c = body.querySelector("#closed-captions-button");
        setTimeout(()=>{
        if(c!=null)
        {c.click();
        }
        else{console.log("Not clicked 3");}
    },200);
    }
    else{console.log("Not clicked 2");}
},100);
}
else{console.log("Not clicked 1");}
//wrapping all in settime out to create delay bcos b not load

    
    setTimeout(()=>{
        //iframe
        // var i = document.querySelector('iframe');
        // var body =i.contentDocument.childNodes[1].childNodes[1]
        
        const outerBox = body.querySelector('[data-tid="closed-captions-renderer"]');
        
console.log(typeof(outerBox));

    observer.observe(outerBox, { childList: true,subtree:true});
},8000);

}



let addedScript=[];
let speaker1="";
let speaker2="";
let newScript="";
let counter =0;

var observer = new MutationObserver(mutations => {
    // var last5=["","","","","","","","","","","","","","","","","","","",""];
    // var st=0;
    var buffer=[];
    mutations.forEach(function(mutation){
        mutation.addedNodes.forEach((node)=>{
            setTimeout(()=> {
                console.log(node);

                if(buffer.length>=1000)
                {
                    buffer=[];
                }
                
            if(node.nodeName == 'DIV')
            {
                
                if(node.childNodes[0].childNodes[1] )
                {
                    
                    speaker1=node.childNodes[0].childNodes[1].innerText; 
                    console.log(speaker1+" ");
                }
                
                if(node.childNodes[1])
                {
                    newScript+=node.childNodes[1].innerText;
                    
                    if(!buffer.includes(newScript)){
                        
                        addedScript.push(newScript); 
                        console.log(newScript);
                       
                        buffer.push(newScript);
                    }
                    
                }
            }
           
            if(addedScript.length>0 && addedScript.length< 500)
            {
                let removed = addedScript.splice(0,addedScript.length);
                removed = removed.join(" ");
                counter+=removed.length;
               
                console.log(counter);
                if(counter>1000)
                {
                    speaker2="";
                    counter=0;
                }
                if(speaker2!==speaker1)
                {transcript+=("\n"+speaker1+": "+removed);
                speaker2=speaker1;
                counter=0;
                }
            else{
                transcript+=(" "+removed);
            }
            }
            else{
                newScript="";
                removed="";
                
            }
            newScript="";
            
            
        },10000);
        });
        
    })
});

/*
*****************LOGS**************************
24-01-23
1) added variable tempdate 
2) applyied logic that it will capture and delete from dom so that no repetation
3)problem is the name is capturing in the loop
line 77-85

*/