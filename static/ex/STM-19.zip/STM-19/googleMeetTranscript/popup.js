document.addEventListener('DOMContentLoaded', function() {//we need this DOMContentLoaded() because the backgroung sript and this popup runs before content script and will give null error so we use it
    document.querySelector('#submit').addEventListener('click', function() {
      var email = document.querySelector('#email').value;
      
      //   chrome.runtime.sendMessage({email: email});
      //   alert("send");
      // window.close();

      chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
        chrome.tabs.sendMessage(tabs[0].id, {myVariable: email});
      });// this code will filter out he active tabs of current window on which extension is running
      

      //alert("send:"+email);
    });
  });
  