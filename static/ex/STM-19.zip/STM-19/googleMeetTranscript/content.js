let transcript="";
let meetId =""; 
let email_id = "";

//listerning email id dynamic
chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
    if (request.myVariable) {
      email_id = request.myVariable;
      alert("Summary of this meeting will be sent to: "+email_id);
     
    }
  });

  
window.onload=func;
var a1 = document.createElement("a");


function summary(){
    
    const data = transcript;
    
    //Uisg fetch api

    fetch('http://127.0.0.1:8000/predict',{
        method:'POST',
        headers:{
            'Content-Type':'application/json'
        },
        body: JSON.stringify({
            Transcript: transcript,
            MeetId: meetId,
            Email_id: email_id

            
        })
    })
    .then(response => response.json())
    .then(data => {
        if(data["status"] == "send")
        {
            alert("Email send successfully, Please also check spam!");
        }
        else{
            alert("Error");
        }
    })
    .catch(error => {
        console.error(error);
    });
   

    
}

//end of meet
window.addEventListener('beforeunload', function (e) {
    e.preventDefault();
    
    if(transcript.length>0){
        alert("Email send successfully, Please also check spam!");// writing alert here because the mail is send after the tab is closed in between the page is changed we cannot get alert from summary()
        var filedata = "Meeting-id: "+meetId+"\n"+"Host email-id: "+email_id+"\n"+transcript; 
        var blob1 = new Blob([filedata], {type: "text/plain;charset=utf-8"});
    


    
    a1.href = window.URL.createObjectURL(blob1);
    a1.download = (meetId+"Script.txt");
    a1.click();
    

    // code to  send post request to ML model using api
    summary();
    

    }

});

function func()
{
    
    
    
    const button = document.createElement("button");
    button.id = "recordTranscript";
    button.textContent = "Start";
    button.style.backgroundColor="rgb(47, 255, 68)";
    button.style.position= "absolute";
    button.style.bottom = "27px";
    button.style.zIndex="3";
    button.style.right="260px";
    button.style.height="30px";
    button.style.width="80px"

    

    document.querySelector("body").prepend(button);//inserting a 'start' button.

    button.addEventListener('click',onCaption);//clicking to start

   

    

    
}

function onCaption(){

//taking users email.id
// try{
console.log(email_id);
//  var a  = document.querySelector("#ow3 > div.T4LgNb > div > div:nth-child(13) > div.crqnQb > div.J0M6X.nulMpf.Didmac.G03iKb > div > div > div.Tmb7Fd > div > div.juFBl > span > button > span:nth-child(4)");
var a = document.querySelector("#ow3 > div.T4LgNb > div > div:nth-child(13) > div.crqnQb > div.fJsklc.nulMpf.Didmac.G03iKb > div > div > div.Tmb7Fd > div > div.juFBl > span > button"); 
if(a==null)
 a = document.querySelector("#ow3 > div.T4LgNb > div > div:nth-child(14) > div.crqnQb > div.J0M6X.nulMpf.Didmac.G03iKb > div > div > div.Tmb7Fd > div > div.juFBl > span > button > span:nth-child(4)");
    if(a!=null)
    a.click();
    // 
    // meetId = document.querySelector("#ow3 > div.T4LgNb > div > div:nth-child(13) > div.crqnQb > div.J0M6X.nulMpf.Didmac.G03iKb > div > div > div.lefKC > div > div > div > span > div.u6vdEc.ouH3xe");
    meetId = document.querySelector("#ow3 > div.T4LgNb > div > div:nth-child(13) > div.crqnQb > div.fJsklc.nulMpf.Didmac.G03iKb > div > div > div.lefKC > div > div > div > span > div.u6vdEc.ouH3xe");
    if(meetId==null)
    {meetId= document.querySelector("#ow3 > div.T4LgNb > div > div:nth-child(14) > div.crqnQb > div.J0M6X.nulMpf.Didmac.G03iKb > div > div > div.lefKC > div > div > div > span > div.u6vdEc.ouH3xe");
    
}
meetId = meetId.innerText;
    // const outerBox = document.querySelector("#ow3 > div.T4LgNb > div > div:nth-child(13) > div.crqnQb > div.a4cQT > div:nth-child(1) > div:nth-child(1)");
   
   const outerBox = document.querySelector("#ow3 > div.T4LgNb > div > div:nth-child(13) > div.crqnQb > div.a4cQT > div:nth-child(1) > div:nth-child(1)");
    if(outerBox==null) outerBox = document.querySelector("#ow3 > div.T4LgNb > div > div:nth-child(14) > div.crqnQb > div.a4cQT > div:nth-child(1) > div:nth-child(1)");

    observer.observe(outerBox, { childList: true,subtree:true});

// }
// catch(err)
// {
//     alert("Meet not loaded properly please try again in few seconds!");
// }
}




let addedScript=[];
let speaker1="";
let speaker2="";
let newScript="";
let counter =0;

var observer = new MutationObserver(mutations => {
    
    mutations.forEach(function(mutation){
        mutation.addedNodes.forEach((node)=>{
            setTimeout(()=> {
            if(node.nodeName == 'DIV')
            {
                if(node.childNodes[1])
                {
                    speaker1=node.childNodes[1].innerText; 
                }
            }
            if(node.nodeName == 'SPAN')
            {                
                newScript+=node.innerText;
                addedScript.push(newScript);    
            }

            if(addedScript.length>0 && addedScript.length< 500)
            {
                let removed = addedScript.splice(0,addedScript.length);
                removed = removed.join(" ");
                counter+=removed.length;
               
                
                if(counter>1000)
                {
                    speaker2="";
                    counter=0;
                }
                if(speaker2!==speaker1)
                {transcript+=("\n"+speaker1+": "+removed);
                speaker2=speaker1;
                counter=0;
            }
            else{
                transcript+=(" "+removed);
            }
            }
            else{
                newScript="";
                removed="";
                
            }
            newScript="";
            
            
        },10000);
        });
        
    })
});

